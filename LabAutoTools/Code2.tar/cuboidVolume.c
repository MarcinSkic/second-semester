int cuboidVolume(int a, int b, int h){
    return a*b*h;
}