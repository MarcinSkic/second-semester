int rectangleArea (int a, int b){
    return a*b;
}