int rectangleArea(int a, int b);
int cuboidArea(int a, int b, int h);