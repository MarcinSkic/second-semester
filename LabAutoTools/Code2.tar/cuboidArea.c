int cuboidArea(int a, int b, int h){
    return 2*(a*b+b*h+h*a);
}